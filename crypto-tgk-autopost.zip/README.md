# Crypto TGK Autopost
Автопостинг в Telegram-канал через GitHub Actions.